package com.example.picpic;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.renderscript.Allocation;
import android.renderscript.Element;
import android.renderscript.RenderScript;
import android.renderscript.ScriptIntrinsicBlur;

public class ImageUtils {

    public static Bitmap applyBlur(Context context, Bitmap image, float blurRadius) {
        RenderScript renderScript = RenderScript.create(context);

        // 비트맵을 RenderScript용으로 변환
        Allocation input = Allocation.createFromBitmap(renderScript, image);
        Allocation output = Allocation.createTyped(renderScript, input.getType());

        // 블러 처리를 위한 스크립트 생성
        ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(renderScript, Element.U8_4(renderScript));
        script.setInput(input);
        script.setRadius(blurRadius);

        // 블러 처리된 결과 얻기
        script.forEach(output);
        output.copyTo(image);

        // 리소스 해제
        renderScript.destroy();

        return image;
    }

    public static Bitmap applyStrongBlur(Context context, Bitmap source, float blurRadius, Path path) {
        if (source == null) {
            return null;
        }

        // Create a RenderScript context
        RenderScript rs = RenderScript.create(context);

        // Allocate memory for Renderscript to work with
        final Allocation input = Allocation.createFromBitmap(rs, source);
        final Allocation output = Allocation.createTyped(rs, input.getType());

        // Create a blur script and set the blur radius
        ScriptIntrinsicBlur script = ScriptIntrinsicBlur.create(rs, Element.U8_4(rs));
        script.setInput(input);
        script.setRadius(blurRadius);

        // Perform the blur only within the specified path
        script.forEach(output);

        // Copy the output to the blurred bitmap
        output.copyTo(source);

        // Apply the path only if provided
        if (path != null) {
            applyPathMask(source, path);
        }

        // Destroy the Renderscript context
        rs.destroy();

        return source;
    }

    private static void applyPathMask(Bitmap bitmap, Path path) {
        Canvas canvas = new Canvas(bitmap);
        canvas.drawPath(path, ImageUtils.createPathPaint());
    }

    private static Paint createPathPaint() {
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
        return paint;
    }
}
