
package com.example.picpic;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Region;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.google.api.gax.core.FixedCredentialsProvider;
import com.google.auth.oauth2.ServiceAccountCredentials;
import com.google.cloud.vision.v1.AnnotateImageRequest;
import com.google.cloud.vision.v1.AnnotateImageResponse;
import com.google.cloud.vision.v1.BatchAnnotateImagesResponse;
import com.google.cloud.vision.v1.BoundingPoly;
import com.google.cloud.vision.v1.EntityAnnotation;
import com.google.cloud.vision.v1.Feature;
import com.google.cloud.vision.v1.Image;
import com.google.cloud.vision.v1.ImageAnnotatorClient;
import com.google.cloud.vision.v1.ImageAnnotatorSettings;
import com.google.cloud.vision.v1.Vertex;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.protobuf.ByteString;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {
    private static final int PICK_IMAGE_REQUEST= 1;
    private ImageView imageView;

    private static final float RECTANGLE_WIDTH= 20;
    private static final float RECTANGLE_HEIGHT= 20;

    private JsonArray existingBoundingBoxes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 기존에 이미지에 그려진 바운딩 박스의 좌표를 초기화 (예시로 임의의 좌표 추가)
        existingBoundingBoxes = new JsonArray();
        JsonObject exampleBoundingBox = new JsonObject();
        exampleBoundingBox.addProperty("x", 50);
        exampleBoundingBox.addProperty("y", 50);
        existingBoundingBoxes.add(exampleBoundingBox);

        // Cloud Vision SDK 초기화
        try {
            Class.forName("com.google.cloud.vision.v1.ImageAnnotatorClient");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

        imageView = findViewById(R.id.imageView);

        findViewById(R.id.btnSelectImage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });

        findViewById(R.id.btnTestImage).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testImage();
            }
        });

        findViewById(R.id.btnBlur).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                blurSelectedRegion();
            }
        });

    }

    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent,PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode ==PICK_IMAGE_REQUEST&& resultCode ==RESULT_OK&& data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            displaySelectedImage(imageUri);
        }
    }

    private void displaySelectedImage(Uri imageUri) {
        try {
            InputStream imageStream = getContentResolver().openInputStream(imageUri);
            Bitmap selectedImage = BitmapFactory.decodeStream(imageStream);
            imageView.setImageBitmap(selectedImage);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void testImage() {
        if (imageView.getDrawable() == null) {
            showErrorDialog("Error", "Please select an image first");
            return;
        }

        Log.d("MainActivity", "Testing image...");

        try {
            Bitmap bitmap = getBitmapFromImageView();
            if (bitmap != null) {
                Log.d("MainActivity", "Bitmap obtained");
                detectTextFromImage(bitmap);
            } else {
                showErrorDialog("Error", "Failed to get bitmap from ImageView");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Error", e.getMessage());
        }
    }

    private Bitmap getBitmapFromImageView() {
        try {
            Drawable drawable = imageView.getDrawable();
            if (drawable instanceof BitmapDrawable) {
                return ((BitmapDrawable) drawable).getBitmap();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private void detectTextFromImage(Bitmap bitmap) {
        Log.d("MainActivity", "Detecting text from image...");

        try {
            // 리소스 ID 얻기
            int resId = getResources().getIdentifier("credentials", "raw", getPackageName());

            // InputStream으로 파일 읽기
            InputStream credentialsStream = getResources().openRawResource(resId);

            // API 키를 설정하여 ImageAnnotatorClient를 생성
            ServiceAccountCredentials credentials = ServiceAccountCredentials.fromStream(credentialsStream);
            ImageAnnotatorSettings settings = ImageAnnotatorSettings.newBuilder()
                    .setCredentialsProvider(FixedCredentialsProvider.create(credentials))
                    .build();
            ImageAnnotatorClient vision = ImageAnnotatorClient.create(settings);

            ByteArrayOutputStream stream = new ByteArrayOutputStream();
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
            byte[] imageBytes = stream.toByteArray();
            ByteString byteString = ByteString.copyFrom(imageBytes);

            Image image = Image.newBuilder().setContent(byteString).build();
            Feature feature = Feature.newBuilder().setType(Feature.Type.TEXT_DETECTION).build();
            AnnotateImageRequest request =
                    AnnotateImageRequest.newBuilder().addFeatures(feature).setImage(image).build();

            BatchAnnotateImagesResponse responses = vision.batchAnnotateImages(Collections.singletonList(request));

            StringBuilder resultText = new StringBuilder();

            for (AnnotateImageResponse res : responses.getResponsesList()) {
                if (res.hasError()) {
                    String errorMessage = res.getError().getMessage();
                    Log.e("Vision API Error", errorMessage);
                    showErrorDialog("Error", errorMessage);
                    return;
                }

                // 문장 단위로 좌표 추출
                resultText.append(extractSentenceCoordinates(res)).append("\n");
            }

            showTextDialog("Coordinates Result", resultText.toString());
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("Error", e.getMessage());
        }
    }

    private String convertResponseToJson(AnnotateImageResponse response) {
        Gson gson = new GsonBuilder().setLenient().create();
        try {
            JsonObject jsonObject = new JsonObject();
            JsonArray sentencesJsonArray = new JsonArray();

            // 좌표 정보를 sentenceJson에 추가
            sentencesJsonArray.add(extractSentenceCoordinates(response));

            // sentencesJsonArray를 메인 jsonObject에 추가
            jsonObject.add("sentences", sentencesJsonArray);

            // Gson을 이용해 JSON 문자열로 변환
            return gson.toJson(jsonObject);
        } catch (Exception e) {
            e.printStackTrace();
            Log.e("JSON Conversion Error", "Failed to convert response to JSON: " + e.getMessage());
            return "Failed to convert response to JSON: " + e.getMessage();
        }
    }


    private void showErrorDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title)
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create()
                .show();
    }

    private void showTextDialog(String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(title);
        builder.setMessage(message);

        // 확인 버튼 추가
        builder.setPositiveButton("확인", (dialog, which) -> {
            // JSON 메시지 파싱하여 바운딩 상자 표시
            JsonArray sentencesArray = JsonParser.parseString(message).getAsJsonArray();
            for (JsonElement sentenceElement : sentencesArray) {
                JsonObject sentenceJson = sentenceElement.getAsJsonObject();
                String text = sentenceJson.getAsJsonPrimitive("text").getAsString();
                JsonArray boundingBoxArray = sentenceJson.getAsJsonArray("boundingBox");

                // 이미지 위에 바운딩 상자 그리기
                drawBoundingBoxOnImage(boundingBoxArray);

                // 출력에 좌표 정보 추가
                String output = "Text: " + text + "\nBoundingBox: " + boundingBoxArray.toString();
                Log.d("Text and BoundingBox", output);
            }
            dialog.dismiss();
        }).create().show();
    }


    // drawBoundingBoxOnImage 메서드 내에서 호출
    private void drawBoundingBoxOnImage(JsonArray boundingBoxArray) {
        // Get the original bitmap from ImageView
        Bitmap originalBitmap = getBitmapFromImageView();

        // Create a mutable bitmap
        Bitmap bitmap = originalBitmap.copy(originalBitmap.getConfig(), true);

        // Create a canvas for drawing on the mutable bitmap
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint();
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);

        float left = Float.MAX_VALUE;
        float top = Float.MAX_VALUE;
        float right = Float.MIN_VALUE;
        float bottom = Float.MIN_VALUE;

        // Find the minimum and maximum coordinates to create a bounding box
        for (int i = 0; i < boundingBoxArray.size(); i++) {
            JsonObject vertexJson = boundingBoxArray.get(i).getAsJsonObject();
            float x = vertexJson.getAsJsonPrimitive("x").getAsFloat();
            float y = vertexJson.getAsJsonPrimitive("y").getAsFloat();

            left = Math.min(left, x);
            top = Math.min(top, y);
            right = Math.max(right, x + RECTANGLE_WIDTH);
            bottom = Math.max(bottom, y + RECTANGLE_HEIGHT);
        }

        // Draw a single rectangle that encompasses all words
        canvas.drawRect(left, top, right, bottom, paint);

        // Update the ImageView with the modified bitmap
        imageView.setImageBitmap(bitmap);
    }

    // extractSentenceCoordinates 메서드 수정
    private JsonArray extractSentenceCoordinates(AnnotateImageResponse response) {
        JsonArray sentencesJsonArray = new JsonArray();

        for (EntityAnnotation annotation : response.getTextAnnotationsList()) {
            String text = annotation.getDescription();

            // 좌표 정보 추출
            BoundingPoly boundingPoly = annotation.getBoundingPoly();
            JsonArray verticesJsonArray = new JsonArray();
            for (Vertex vertex : boundingPoly.getVerticesList()) {
                JsonObject vertexJson = new JsonObject();
                vertexJson.addProperty("x", vertex.getX());
                vertexJson.addProperty("y", vertex.getY());
                verticesJsonArray.add(vertexJson);
            }

            // 좌표 정보를 sentenceJson에 추가
            JsonObject sentenceJson = new JsonObject();
            sentenceJson.addProperty("text", text);
            sentenceJson.add("boundingBox", verticesJsonArray);

            // sentenceJson을 sentencesJsonArray에 추가
            sentencesJsonArray.add(sentenceJson);

            // 추출된 좌표를 로그로 출력
            Log.d("MainActivity", "Text: " + text + ", BoundingBox: " + verticesJsonArray);
        }

        return sentencesJsonArray;
    }


    private BoundingPoly getBoundingPolyForSentence(AnnotateImageResponse response, String sentence) {
        BoundingPoly bestMatch = null;
        int bestMatchScore = Integer.MAX_VALUE;  // 초기값 설정

        for (EntityAnnotation annotation : response.getTextAnnotationsList()) {
            String annotationText = annotation.getDescription();

            // 간단한 유사성 점수 계산 (더 정교한 방법을 사용하려면 더 많은 로직 필요)
            int matchScore = calculateSimilarityScore(sentence, annotationText);

            // 현재까지의 최적 매칭보다 더 유사하면 업데이트
            if (matchScore < bestMatchScore) {
                bestMatch = annotation.getBoundingPoly();
                bestMatchScore = matchScore;
            }
        }

        return bestMatch != null ? bestMatch : BoundingPoly.newBuilder().build();
    }

    // 간단한 유사성 점수 계산 메서드 (더 정교한 방법 필요)
    private int calculateSimilarityScore(String str1, String str2) {
        // 간단한 방법으로 두 문자열 간의 유사성 점수 계산
        // 여기에 더 정교한 알고리즘을 사용하면 더 나은 결과를 얻을 수 있음
        return Math.abs(str1.length() - str2.length());
    }

    private JsonArray extractBoundingBoxCoordinates() {
        if (imageView.getDrawable() == null) {
            showErrorDialog("Error", "Please select an image first");
            return new JsonArray();
        }

        Bitmap originalBitmap = getBitmapFromImageView();
        float viewWidth = imageView.getWidth();
        float viewHeight = imageView.getHeight();

        JsonArray boundingBoxArray = new JsonArray();

        // Check if there are existing bounding boxes drawn on the image
        if (existingBoundingBoxes != null && !existingBoundingBoxes.isJsonNull() && existingBoundingBoxes.size() > 0) {
            // Use existing bounding box coordinates
            boundingBoxArray = existingBoundingBoxes.getAsJsonArray();
        } else {
            // Example: Extract coordinates for a rectangular region (adjust as needed)
            float left = 0.2f * viewWidth;
            float top = 0.2f * viewHeight;
            float right = 0.8f * viewWidth;
            float bottom = 0.8f * viewHeight;

            // Convert to image coordinates
            float imageLeft = (left / viewWidth) * originalBitmap.getWidth();
            float imageTop = (top / viewHeight) * originalBitmap.getHeight();
            float imageRight = (right / viewWidth) * originalBitmap.getWidth();
            float imageBottom = (bottom / viewHeight) * originalBitmap.getHeight();

            JsonObject vertexJson = new JsonObject();
            vertexJson.addProperty("x", imageLeft);
            vertexJson.addProperty("y", imageTop);
            boundingBoxArray.add(vertexJson);

            vertexJson = new JsonObject();
            vertexJson.addProperty("x", imageRight);
            vertexJson.addProperty("y", imageTop);
            boundingBoxArray.add(vertexJson);

            vertexJson = new JsonObject();
            vertexJson.addProperty("x", imageRight);
            vertexJson.addProperty("y", imageBottom);
            boundingBoxArray.add(vertexJson);

            vertexJson = new JsonObject();
            vertexJson.addProperty("x", imageLeft);
            vertexJson.addProperty("y", imageBottom);
            boundingBoxArray.add(vertexJson);
        }

        return boundingBoxArray;
    }


    private void blurSelectedRegion() {
        if (imageView.getDrawable() == null) {
            showErrorDialog("오류", "먼저 이미지를 선택하세요");
            return;
        }

        Log.d("MainActivity", "선택한 영역 블러 처리 중...");

        try {
            Bitmap bitmap = getBitmapFromImageView();
            if (bitmap != null) {
                Log.d("MainActivity", "비트맵 획득 완료");

                // 여기서 추가된 부분
                float blurRadius = 25f; // 필요한만큼 조절
                Bitmap blurredBitmap = ImageUtils.applyStrongBlur(getApplicationContext(), bitmap, blurRadius, null);


                // 선택한 영역의 좌표를 가져옴
                JsonArray boundingBoxArray = extractBoundingBoxCoordinates();

                // 선택한 영역에 대해서만 블러 처리
                Bitmap finalBitmap = blurSelectedRegionOnImage(boundingBoxArray, bitmap, blurredBitmap);

                // ImageView를 최종 블러된 비트맵으로 업데이트
                imageView.setImageBitmap(finalBitmap);

                // 블러 처리가 완료되었음을 알리는 토스트 메시지 표시
                showToast("블러 처리 완료!");
            } else {
                showErrorDialog("오류", "ImageView에서 비트맵을 가져오지 못했습니다");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showErrorDialog("오류", e.getMessage());
        }
    }

    private Bitmap blurSelectedRegionOnImage(JsonArray boundingBoxArray, Bitmap bitmap, Bitmap blurredBitmap) {
        // Create a mutable bitmap
        Bitmap mutableBitmap = bitmap.copy(bitmap.getConfig(), true);

        // Create a canvas for drawing on the mutable bitmap
        Canvas canvas = new Canvas(mutableBitmap);
        Paint paint = new Paint();
        paint.setAntiAlias(true);
        paint.setFilterBitmap(true);

        // Identify the bounding box with the maximum area
        JsonObject largestBoundingBox = findLargestBoundingBox(boundingBoxArray);

        // Set up a path for the selected region
        Path path = new Path();
        for (int i = 0; i < boundingBoxArray.size(); i++) {
            JsonObject vertexJson = boundingBoxArray.get(i).getAsJsonObject();
            float x = vertexJson.getAsJsonPrimitive("x").getAsFloat();
            float y = vertexJson.getAsJsonPrimitive("y").getAsFloat();

            if (i == 0) {
                path.moveTo(x, y);
            } else {
                path.lineTo(x, y);
            }
        }
        path.close();

        // Check if the path goes beyond the image boundaries
        RectF bounds = new RectF();
        path.computeBounds(bounds, true);

        if (bounds.left < 0 || bounds.top < 0 || bounds.right > bitmap.getWidth() || bounds.bottom > bitmap.getHeight()) {
            // The path extends beyond the image boundaries, do not apply blur
            return mutableBitmap;
        }

        // Blur the selected region only if it is not the largest bounding box
        if (!isBoundingBoxLargest(boundingBoxArray, largestBoundingBox)) {
            float blurRadius = 25f; // 필요한만큼 조절
            ImageUtils.applyStrongBlur(getApplicationContext(), mutableBitmap, blurRadius, path);
        }

        // Draw the selected region on the canvas
        paint.setXfermode(null);
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(5);
        canvas.drawPath(path, paint);

        // Return the modified bitmap
        return mutableBitmap;
    }

    private boolean isBoundingBoxLargest(JsonArray boundingBoxArray, JsonObject largestBoundingBox) {
        // Check if the boundingBoxArray has the same coordinates as the largestBoundingBox
        // You may need to adjust this logic based on how you compare bounding boxes
        return boundingBoxArray.equals(largestBoundingBox.getAsJsonArray("boundingBox"));
    }

    private JsonObject findLargestBoundingBox(JsonArray boundingBoxArray) {
        // Implement the logic to find the largest bounding box in the array
        // For simplicity, I'll return the first bounding box as an example
        if (boundingBoxArray.size() > 0) {
            return boundingBoxArray.get(0).getAsJsonObject();
        } else {
            return new JsonObject();
        }
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    private void blurSelectedRegionPixels(Bitmap bitmap, Path path) {
        // Adjust pixel values in the selected region for a blur effect
        int[] pixels = new int[bitmap.getWidth() * bitmap.getHeight()];
        bitmap.getPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());

        // Loop through each pixel in the selected region
        Region region = new Region();
        Region clip = new Region(0, 0, bitmap.getWidth(), bitmap.getHeight());
        region.setPath(path, clip);
        Rect bounds = region.getBounds();

        for (int y = bounds.top; y < bounds.bottom; y++) {
            for (int x = bounds.left; x < bounds.right; x++) {
                if (region.contains(x, y)) {
                    // Adjust pixel values for blur effect (you can implement a more sophisticated blur algorithm here)
                    // For simplicity, we'll just darken the pixels
                    int pixelIndex = y * bitmap.getWidth() + x;
                    int pixel = pixels[pixelIndex];
                    int alpha = Color.alpha(pixel);
                    int red = Color.red(pixel);
                    int green = Color.green(pixel);
                    int blue = Color.blue(pixel);

                    // Darken the pixel values
                    red = red / 2;
                    green = green / 2;
                    blue = blue / 2;

                    // Set the adjusted pixel back to the array
                    pixels[pixelIndex] = Color.argb(alpha, red, green, blue);
                }
            }
        }

        // Set the modified pixels back to the bitmap
        bitmap.setPixels(pixels, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
    }
}